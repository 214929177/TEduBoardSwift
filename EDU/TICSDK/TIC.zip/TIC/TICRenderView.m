//
//  TICRenderView.m
//  TIC_Demo_Mac
//
//  Created by kennethmiao on 2019/4/1.
//  Copyright © 2019年 Tencent. All rights reserved.
//

#import "TICRenderView.h"

@implementation TICRenderView
@end
